// Smooth scrolling
document.querySelectorAll('a[href^="#"]').forEach(link => {
  link.addEventListener("click", e => {
    const href = (e.currentTarget as HTMLAnchorElement).getAttribute("href");
    if (!href) return;
    const target = document.querySelector(href);
    if (target) {
      e.preventDefault();
      target.scrollIntoView({ behavior: "smooth" });
    }
  });
});

// Theme toggle
const toggle = document.getElementById("themeToggle")!;
toggle.addEventListener("click", () => {
  const theme = document.body.getAttribute("data-theme");
  if (theme === "light") {
    document.body.removeAttribute("data-theme");
    toggle.textContent = "🌙";
  } else {
    document.body.setAttribute("data-theme", "light");
    toggle.textContent = "☀️";
  }
});

// Contact form (client-side demo)
const form = document.getElementById("contactForm") as HTMLFormElement;
const status = document.getElementById("formStatus") as HTMLParagraphElement;

form.addEventListener("submit", e => {
  e.preventDefault();
  const formData = new FormData(form);
  const name = formData.get("name");
  status.textContent = `Thanks, ${name}! Your message was received.`;
  form.reset();
});